#ifndef _GAME_H_
#define _GAME_H_
#include "gamecontroller.h"

class Game {
    public:
    Gamecontroller G;
    Game(bool cancheat);
};
#endif
